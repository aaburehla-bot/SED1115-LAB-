"""
Read log.txt (exported from the Pico) and plot a histogram of the
time it took the player to count 15 seconds.

Usage:  python plot_histogram.py [log.txt]
Requires: matplotlib  (pip install matplotlib)
"""

import sys
import matplotlib.pyplot as plt

filename = sys.argv[1] if len(sys.argv) > 1 else "log.txt"

times = []
with open(filename) as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            # Format: "YYYY-MM-DD HH:MM:SS,elapsed_seconds"
            times.append(int(line.split(",")[-1]))
        except ValueError:
            print("Skipping malformed line:", line)

if not times:
    sys.exit("No data found in " + filename)

# One bin per whole second, centred on the integer value
bins = [t - 0.5 for t in range(min(times), max(times) + 2)]

plt.figure(figsize=(8, 5))
plt.hist(times, bins=bins, edgecolor="black")
plt.axvline(15, color="red", linestyle="--", label="Target (15 s)")
plt.xlabel("Time counted by player (s)")
plt.ylabel("Number of trials")
plt.title("Perception of 15 seconds ({} trials)".format(len(times)))
plt.xticks(range(min(times), max(times) + 1))
plt.legend()
plt.tight_layout()
plt.savefig("histogram.png", dpi=150)
plt.show()

print("Mean: {:.2f} s, min: {} s, max: {} s".format(
    sum(times) / len(times), min(times), max(times)))
