"""
Bonus: compare the Pico's oscillator (time.ticks_us) against the DS3231 RTC.

Every time the RTC seconds register rolls over to :00 (once a minute) we log:
    rtc_elapsed_s, pico_elapsed_us
Run it for a long time (hours). Then compute:
    drift_ppm = (pico_elapsed_us - rtc_elapsed_s * 1e6) / (rtc_elapsed_s * 1e6) * 1e6
A positive value means the Pico clock runs FAST relative to the RTC.

To compare against an NTP-synced computer, note the computer's time at the
start and the end of the run (e.g. by printing them over USB serial) and
compare that wall-clock interval with rtc_elapsed_s.
"""

from machine import Pin, I2C
import time

RTC_ADDR = 0x68
i2c = I2C(1, sda=Pin(14), scl=Pin(15))


def rtc_seconds():
    """Read only the seconds register (fast) and decode BCD."""
    b = i2c.readfrom_mem(RTC_ADDR, 0x00, 1)[0]
    return (b >> 4) * 10 + (b & 0x0F)


def wait_for_edge(last):
    """Poll until the RTC seconds value changes; return (new_sec, ticks_us)."""
    while True:
        s = rtc_seconds()
        if s != last:
            return s, time.ticks_us()


log = open("drift_log.txt", "a")
try:
    sec = rtc_seconds()
    sec, t0 = wait_for_edge(sec)          # sync to a second boundary
    rtc_elapsed = 0                       # RTC seconds since t0

    while True:
        new_sec, t = wait_for_edge(sec)
        rtc_elapsed += (new_sec - sec) % 60
        sec = new_sec

        if sec == 0:                      # log once per minute
            pico_us = time.ticks_diff(t, t0)
            log.write("{},{}\n".format(rtc_elapsed, pico_us))
            log.flush()
            print(rtc_elapsed, pico_us)
except KeyboardInterrupt:
    print("Stopped.")
finally:
    log.close()
